<?php
/**
 * Created by PhpStorm.
 * User: Philipp Schuepbach
 * Date: 07.11.2017
 * Time: 11:12
 */

class datenbank
{
    private $Name;
    private $DB;

    /**
     * SQLiteDatabase constructor.
     */
    public function __construct($n)
    {
        $this->Name = $n;
        $this->DB = new PDO("sqlite:" . $n);
    }

    public function getDataAsArray($t): array
    {
        $result = $this->DB->query("SELECT * FROM " . $t . ";");
        if (gettype($result)=="boolean"){
            throw new Exception("Statement equals ".$result);
        }
        if ($result->errorCode()>0) {
            throw new Exception($result->errorCode() . ": " . serialize($result->errorInfo()));
        }
        $array = $result->fetchAll(PDO::FETCH_ASSOC);
        if (!$array) {
            throw new Exception("Something went wrong while fetching.");
        }
        $result->closeCursor();
        return $array;
    }

    public function getQueryAsArray(string $q):array {
        $result = $this->DB->query($q);
        if (gettype($result)=="boolean"){
            throw new Exception("Statement equals ".$result);
        }
        if ($result->errorCode()>0) {
            throw new Exception($result->errorCode() . ": " . serialize($result->errorInfo()));
        }
        $array = $result->fetchAll(PDO::FETCH_ASSOC);
        if (!$array) {
            throw new Exception("Something went wrong while fetching.");
        }
        $result->closeCursor();
        return $array;
    }

}