/**
 * @author Sahithyen Kanaganayagam <mail@sahithyen.com>
 * @license MIT
 */

const m = require('mithril')

module.exports = {
  view: function () {
    return m('nav.navbar.navbar-expand-lg.navbar-light.bg-light', [
      m('a.navbar-brand', {
        href: '#'
      }),
      m('button.navbar-toggler', {
        type: 'button',
        'data-toggle': 'collapse',
        'data-target': '#biomasse-navbar',
        'aria-controls': 'biomasse-navbar',
        'aria-expanded': 'false',
        'aria-label': 'Navigation umschalten'
      }, [
        m('span.navbar-toggler-icon')
      ]),

      m('div#biomasse-navbar.collapse.navbar-collapse', [
        m('ul.navbar-nav.mr-auto', [
          m('li.nav-item' + (m.route.get() === '/home' ? '.active' : ''), [
            m('a.nav-link', {
              href: '/home',
              oncreate: m.route.link
            }, 'Startseite')
          ])
        ])
      ])
    ])
  }
}
