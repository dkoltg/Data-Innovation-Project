/**
 * @author Sahithyen Kanaganayagam <mail@sahithyen.com>
 * @license MIT
 */

const m = require('mithril')
const L = require('leaflet')
const wms = require('leaflet.wms')
const $ = require('jquery')

const Map = require('../models/map.js')

const MapLegendView = require('./map-legend')
const MapLayerSelectionView = require('./map-layer-selection')

module.exports = {
  oncreate: vnode => {
    // Get LatLngBounds
    const topLeftCorner = L.latLng(47.7157, 8.6538)
    const bottomRightCorner = L.latLng(47.3730, 9.47)
    const maxBounds = L.latLngBounds(topLeftCorner, bottomRightCorner)

    const biomasseMap = L.map(vnode.dom, {
      minZoom: 11,
      maxZoom: 14, // Maximal max: 14
      maxBounds: maxBounds,
      zoomControl: false,
      attributionControl: false
    })

    var osmLayer = L.tileLayer('http://{s}.tile.osm.org/{z}/{x}/{y}.png', {
      attribution: '&copy; <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
    })

    var biomasseLayer = wms.source(Map.WMSUrl, {
      version: '1.3.0',
      format: 'image/png',
      transparent: true,
      crs: L.CRS.EPSG4326,
      opacity: 1,
      identify: false
    })

    // Create Legend
    var legend = L.control({position: 'bottomleft'})
    legend.onAdd = () => {
      const legendE = L.DomUtil.create('div', 'info-legend')

      m.mount(legendE, MapLegendView)

      return legendE
    }
    legend.addTo(biomasseMap)

    // Create layer selection
    var layerSelection = L.control({position: 'topright'})
    layerSelection.onAdd = () => {
      const layerSelectionE = L.DomUtil.create('div', 'info-legend')

      m.mount(layerSelectionE, MapLayerSelectionView)

      return layerSelectionE
    }
    layerSelection.addTo(biomasseMap)

    // Create layer selection
    var title = L.control({position: 'topleft'})
    title.onAdd = () => {
      const titleE = L.DomUtil.create('div', 'title')

      m.render(titleE, m('div.p-4.bg-white', [
        m('h1', 'Biomasse-Portal'),
        m('p.lead', 'Sehe das Potenzial'),
        m('ul.nav', {
          style: {
            'font-size': '1.4em'
          }
        }, [
          m('li.page-item', [
            m('a.page-link', {
              href: '#',
              onclick: event => {
                $('html, body').animate({
                  scrollTop: $('#informationen').offset().top
                }, 1000)
                event.preventDefault()
              }
            }, 'Informationen')
          ]),
          m('li.page-item', [
            m('a.page-link', {
              href: 'game/'
            }, 'Biomasse-Spiel')
          ])
        ])
      ]))

      return titleE
    }
    title.addTo(biomasseMap)

    // Add zoom control
    var zoom = L.control.zoom({
      position: 'topleft'
    })
    zoom.addTo(biomasseMap)

    // Handle zooming/scrolling
    biomasseMap.scrollWheelZoom.disable()
    // biomasseMap.on('click', function () {
    //   if (biomasseMap.scrollWheelZoom.enabled()) {
    //     biomasseMap.scrollWheelZoom.disable()
    //   } else {
    //     biomasseMap.scrollWheelZoom.enable()
    //   }
    // })

    // Add necessary elements to map
    biomasseMap.addLayer(osmLayer)
    biomasseMap.addLayer(biomasseLayer)

    // Set views
    biomasseMap.setView([47.54, 9.075], 11)

    var lastSelected = 'none'
    this.updateMap = () => {
      const layer = Map.layers[Map.selectedLayer]

      biomasseLayer.removeSubLayer(lastSelected)
      biomasseLayer.addSubLayer(layer.slug)

      lastSelected = layer.slug
    }

    this.updateMap()
  },
  onupdate: () => {
    if (typeof this.updateMap === 'function') {
      this.updateMap()
    }
  },
  view: () => {
    return m('div.map', {
      style: {
        height: '100vh'
      }
    })
  }
}
