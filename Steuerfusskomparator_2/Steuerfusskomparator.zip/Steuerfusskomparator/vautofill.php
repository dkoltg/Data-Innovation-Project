<?php
$db = new SQLite3("ressources/Steuerfuss.sqlite");
$suchen= $_GET['term'];

$autofill= $db->query("SELECT DISTINCT  GeName from Gemeinden WHERE GeName LIKE '".$suchen."%'");

while ($data = $autofill->fetchArray(SQLITE3_ASSOC)) {
    $sug[] = $data['GeName'];

}
echo json_encode($sug);
$db->close();