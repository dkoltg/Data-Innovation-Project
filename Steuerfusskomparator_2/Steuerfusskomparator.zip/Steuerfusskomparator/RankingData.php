<?php

/**
 * Created by PhpStorm.
 * User: Philipp Schuepbach
 * Date: 07.11.2017
 * Time: 10:21
 */
require 'datenbank.php';
error_reporting(E_ALL ^ E_NOTICE);
$DB;
try {
    $DB = new datenbank("ressources/Steuerfuss.sqlite");
} catch (PDOException $e) {
    header("HTTP/1.1 500 Internal Server Error");
    die(0);
}
try {
    $jahr=$_COOKIE['jahr'];
    $typ= $_COOKIE ['typ'];
    $rank=1;
    $query = $DB->getQueryAsArray("SELECT GeName, ".$typ.",StJahr FROM Gemeinden NATURAL JOIN Steuerfuesse WHERE StJahr=".$jahr.";");
    echo "gemeinde\tsteuer\tjahr\trang\r\n";
    foreach($query as $p){
        $z = "";
        foreach ($p as $e){
            $z .= $e."\t";
        }
        $z.=$rank."\t";
        $rank++;
        $z = substr($z,0,strlen($z)-1);
        echo $z."\r\n";
    }
    die(0);
} catch (Exception $e) {
    header("HTTP/1.1 500 Internal Server Error");
    echo $jahr;
    die(0);
}