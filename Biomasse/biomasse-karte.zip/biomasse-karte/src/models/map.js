/**
 * @author Sahithyen Kanaganayagam <mail@sahithyen.com>
 * @license MIT
 */

const Map = {
  WMSUrl: 'http://map.geo.tg.ch//proxy/geofy_chsdi3/biomasse-oberflaeche?access_key=YoW2syIQ4xe0ccJA&',
  selectedLayer: 0,
  layers: [
    {
      id: 0,
      slug: 'hofduenger',
      name: 'Hofdünger',
      description: 't/ha/a => Tonne/Hektare/Jahr'
    },
    {
      id: 1,
      slug: 'kompostierungs_vergaerungsanlagen',
      name: 'Kompostierungs Vergärungslage',
      description: 't/a => Tonne/Jahr'
    },
    {
      id: 2,
      slug: 'waermenachfrage',
      name: 'Wärmenachfrage',
      description: 'MWh/ha/a => Megawattstunde/Hektare/Jahr'
    },
    {
      id: 3,
      slug: 'lebensmittelabfaelle',
      name: 'Lebensmittelabfälle',
      description: 't/a => Tonne/Jahr'
    },
    {
      id: 4,
      slug: 'gruenabfall',
      name: 'Grünabfall',
      description: 't/ha/a => Tonne/Hektare/Jahr'
    },
    {
      id: 5,
      slug: 'kehricht',
      name: 'Kehricht',
      description: 't/ha/a => Tonne/Hektare/Jahr'
    },
    {
      id: 6,
      slug: 'sammeltyp',
      name: 'Sammeltyp',
      description: ''
    },
    {
      id: 7,
      slug: 'erntereste_zwischenfruechte',
      name: 'Erntereste Zwischenfrüchte',
      description: 't/a => Tonne/Jahr'
    }
  ],

  getSelectedLayer: () => Map.layers[Map.selectedLayer],

  getLegendURL: () => {
    const layer = Map.getSelectedLayer()

    return `${Map.WMSUrl}&version=1.3.0&service=WMS&request=GetLegendGraphic&sld_version=1.1.0&layer=${layer.slug}&format=image/png&STYLE=default&`
  }
}

module.exports = Map
