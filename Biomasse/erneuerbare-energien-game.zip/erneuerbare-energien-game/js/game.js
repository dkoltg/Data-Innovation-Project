/**
 *
 *
 */

/* globals createjs */

(root => {
  /**
   * Globals
   */

  var opt = {
    width: 720,
    height: 720 / 16 * 9,
    ratio: window.devicePixelRatio
  }

  /**
   * Helpers
   */

  function rand (items) {
    return items[~~(items.length * Math.random())]
  }

  function getRectangleCentered (r) {
    var rc = {}

    rc.hw = r.width / 2
    rc.hh = r.height / 2
    rc.cx = r.x + rc.hw
    rc.cy = r.y + rc.hh

    return rc
  }

  function getIntersectDelta (a, b) {
    var r1 = getRectangleCentered(a)
    var r2 = getRectangleCentered(b)

    var dx = Math.abs(r1.cx - r2.cx) - (r1.hw + r2.hw)
    var dy = Math.abs(r1.cy - r2.cy) - (r1.hh + r2.hh)

    if (dx < 0 && dy < 0) {
      return {
        x: -dx,
        y: -dy
      }
    } else {
      return null
    }
  }

  /**
   * Assets manager class
   */

  function AssetsManager () {
    this.queue = new createjs.LoadQueue()
    this.queue.loadManifest([
      {
        id: 'carrot', src: 'images/carrot.png'
      },
      {
        id: 'charcoal', src: 'images/charcoal.png'
      },
      {
        id: 'maple-leaf', src: 'images/maple-leaf.png'
      },
      {
        id: 'nuclear-plant', src: 'images/nuclear-plant.png'
      },
      {
        id: 'oak-leaf', src: 'images/oak-leaf.png'
      },
      {
        id: 'oil-pump', src: 'images/oil-pump.png'
      },
      {
        id: 'tomato', src: 'images/tomato.png'
      }
    ], false)
  }

  AssetsManager.prototype.load = function (callback) {
    this.queue.on(
      'complete',
      callback,
      this
    )
    this.queue.load()
  }

  AssetsManager.prototype.get = function (name) {
    return this.queue.getResult(name)
  }

  var assetsManager = new AssetsManager()

  /**
   * Game logic
   */

  // Member variables
  var stage = null
  var paused = true

  // Helpers
  var ar = size => opt.ratio * size

  // Functions
  var tick = event => {
    // TODO: Logic of every tick

    if (event.paused) {
      // TODO: Logic if game is not running
      return
    }

    // TODO: Logic if game is running

    stage.update()
  }

  var setupCanvas = function (canvas) {
    canvas.width = ar(opt.width)
    canvas.height = ar(opt.height)
    canvas.style.width = opt.width + 'px'
    canvas.style.height = opt.height + 'px'
  }

  var gameOver = () => {
    pause()
  }

  var initGame = (canvasEl) => {
    setupCanvas(canvasEl)

    stage = new createjs.Stage(canvasEl)

    assetsManager.load(assetsLoaded)
  }

  var reset = () => {
    // TODO: Reset code
    stage.update()
  }

  var start = () => {
    createjs.Ticker.paused = false
    paused = false
  }

  var pause = () => {
    createjs.Ticker.paused = true
    paused = true
  }

  var assetsLoaded = () => {
    // Begin game
    createjs.Ticker.framerate = 120
    pause()
    createjs.Ticker.addEventListener('tick', tick)

    // Set all values to default
    reset()
  }

  document.addEventListener('keydown', event => {
    switch (event.key) {
      case ' ':

        event.preventDefault()
        break
    }
  })

  document.addEventListener('keyup', event => {
    switch (event.key) {
      case ' ':
        if (paused) {
          reset()
          start()
        }

        event.preventDefault()
        break
    }
  })

  root.initGame = initGame
})(window)
