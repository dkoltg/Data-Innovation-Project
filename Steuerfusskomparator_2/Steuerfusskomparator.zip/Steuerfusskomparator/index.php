<?php error_reporting(E_ALL ^ E_NOTICE); ?>
<!DOCTYPE html>
<html lang="de">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Steuerfusskomperator</title>
    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
</head>

<body>
<!-- Navigation-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top id="mainNav"">
<a class="navbar-brand" href="index.php">
        <span class='span-logo'>
          <img src='ressources/thurgau_logo.png' width="300" height="100" />
        </span>
</a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarResponsive">
    <ul class="nav navbar-nav navbar-right" id="navbarItems">
        <li class="nav-item" data-toggle="tooltip">
            <a class="nav-link" href="index.php">
                <span class="nav-link-text">Home</span>
            </a>
        </li>

        <li class="nav-item" data-toggle="tooltip">
            <a class="nav-link" href="vergleichen.php">
                <span class="nav-link-text">Vergleichen</span>
            </a>
        </li>

        <li class="nav-item" data-toggle="tooltip">
            <a class="nav-link" href="ranking.php">
                <span class="nav-link-text">Ranking</span>
            </a>
        </li>
    </ul>
</div>
</nav>


<div class="content-wrapper">
    <div class="container-fluid" style="float: left;margin-top:20px;">
        <div class="jumbotron">
            <h1>Herzlich Willkommen auf dem Steuerfusskomparator des Kanton Thurgaus</h1>
            <p>Diese Webapplikation wurde von Dominic Gilomen, Niclas Deplazes, Timo Sigrist, Sebastian Schwemer und Philipp Schüpbach im Rahmen des Informatikfachs IPM (Informatik Projektmanagement) an der IMS Frauenfeld realisiert.</p>
        </div>
        <!-- Example DataTables Card-->
        <div class="card mb-3">
            <div class="card-header">
                <i class="fa fa-table"></i>Steuerfüsse der Gemeinden TG</div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                        <tr>
                            <th>Gemeinde</th>
                            <th>Einwohner</th>
                            <th>Jahr</th>
                            <th>Natürliche Person [in %]</th>
                            <th>Katholisch [in %]</th>
                            <th>Evangelisch [in %]</th>
                            <th>Juristische Person [in %]</th>
                        </tr>
                        </thead>
                        <tfoot>
                        <tr>
                            <th>Gemeinde</th>
                            <th>Einwohner</th>
                            <th>Jahr</th>
                            <th>Natürliche Person [in %]</th>
                            <th>Katholisch [in %]</th>
                            <th>Evangelisch [in %]</th>
                            <th>Juristische Person [in %]</th>
                        </tr>
                        </tfoot>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>
    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>
    <!-- Custom scripts for this page-->
    <script src="js/sb-admin-charts.min.js"></script>

    <script>
        data = {"gemeinden":[],"steuerfs":[]};
        function updateData(callback){
            $.post("data.php", function (json, success) {
                if (success === "success") {
                    var response = JSON.parse(json);
                    if (response.typ=="data"){
                        response.arrays.forEach(function (array){
                            switch (array.table){
                                case "Gemeinden":
                                    data.gemeinden = array.data;
                                    break;
                                case "Steuerfuesse":
                                    data.steuerfs = array.data;
                                    break;
                                default: console.log("Unknown table "+array.table);
                            }
                        });
                        var getType={};
                        if(callback && getType.toString.call(callback) === '[object Function]'){
                            callback();
                        }
                    }else{
                        setTimeout(function(){updateData(callback);},1000);
                    }
                }
            }).fail(function () {
                setTimeout(function(){updateData(callback);},1000);
            })
        }
        function writeData(){
            updateData(function(){
                $("#dataTable tbody").empty();
                data.steuerfs.forEach(function(stf){
                    var Gemeinde = {};
                    data.gemeinden.forEach(function (gem) {
                        if(gem.GeId == stf.GeId){
                            Gemeinde = gem;
                        }
                    });
                    var curRow = $("<tr></tr>");
                    Object.keys(Gemeinde).forEach(function(key) {
                        if(key!="GeId"){
                            curRow.append($("<td></td>").text(Gemeinde[key]));
                        }
                    });
                    Object.keys(stf).forEach(function(key) {
                        if(key!=="GeId"){
                            curRow.append($("<td></td>").text(stf[key]));
                        }
                    });
                    $("#dataTable tbody").append(curRow);
                });
            });
        }
        $(function () {
            $("#dataTable").dataTable({"ajax":"data.php"});
            /*var jahrFilter = $('<select> <option default="true">Filter setzen</option><option>2016</option><option>2015</option>2014<option>2013</option>  </select>');
            $("#dataTable_wrapper row").first().firstChild().append(jahrFilter).change(function(){
                $("#dataTable").dataTable().column(3).data().filter(function(value,index){return value==jahrFilter.children("[selected=\"\"]").value() or jahrFilter.children("[selected=\"\"]").value()=="Filter setzen"})
            });*/
        });
    </script>
</div>

</body>
</html>
