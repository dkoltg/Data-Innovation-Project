/**
 * @author Sahithyen Kanaganayagam <mail@sahithyen.com>
 * @license MIT
 */

import 'leaflet/dist/leaflet.css'
import 'bootstrap/dist/css/bootstrap.min.css'

const m = require('mithril')
const HomeView = require('./views/home')

const root = document.querySelector('.wrapper')

m.route(root, '/home', {
  '/home': HomeView
})
