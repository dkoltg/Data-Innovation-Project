/**
 * @author Sahithyen Kanaganayagam <mail@sahithyen.com>
 * @license MIT
 */

const m = require('mithril')

const Map = require('../models/map.js')

module.exports = {
  view: () => {
    return m('div.p-4.bg-white', [
      m('h2', 'Datenauswahl'),
      m('div', [
        Map.layers.map(layer => {
          return m('div.form-check', [
            m('div.form-check-label', [
              m('input.form-check-input', {
                type: 'radio',
                name: 'layer-option',
                value: layer.id,
                onchange: m.withAttr('checked', checked => {
                  if (checked) {
                    Map.selectedLayer = layer.id
                  }
                }),
                checked: layer.id === Map.selectedLayer
              }),
              m('span', layer.name)
            ])
          ])
        })
      ])
    ])
  }
}
