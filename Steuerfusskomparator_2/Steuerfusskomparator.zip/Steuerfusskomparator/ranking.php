<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);

?>
<!DOCTYPE html>
<meta charset="utf-8">
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Steuerfusskomparator-Vergleichen</title>
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
    <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
    <script src ="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.7.1/Chart.bundle.js"></script>
    <script src="js/dia.js"></script>
    <script>
        function findGetParameter(parameterName) {
            var result = null,
                tmp = [];
            location.search
                .substr(1)
                .split("&")
                .forEach(function (item) {
                    tmp = item.split("=");
                    if (tmp[0] === parameterName) result = decodeURIComponent(tmp[1]);
                });
            return result;
        }
    </script>
</head>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top id="mainNav"">
<a class="navbar-brand" href="index.php">
        <span class='span-logo'>
          <img src='ressources/thurgau_logo.png' width="300" height="100" />
        </span>
</a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarResponsive">
    <ul class="nav navbar-nav navbar-right" id="navbarItems">
        <li class="nav-item" data-toggle="tooltip">
            <a class="nav-link" href="index.php">
                <span class="nav-link-text">Home</span>
            </a>
        </li>

        <li class="nav-item" data-toggle="tooltip">
            <a class="nav-link" href="vergleichen.php">
                <span class="nav-link-text">Vergleichen</span>
            </a>
        </li>

        <li class="nav-item" data-toggle="tooltip">
            <a class="nav-link" href="ranking.php">
                <span class="nav-link-text">Ranking</span>
            </a>
        </li>
    </ul>
</div>
</nav>
<style>

    body {
        margin-top:150px;

    }

    .axis path,
    .axis line {
        fill: none;
        stroke: #000;
        shape-rendering: crispEdges;
    }

    .bar {
        fill: #009413;
    }

    .bar:hover {
        fill: #50e13f;
    }

    .x.axis path {
        display: none;
    }

    .d3-tip {
        line-height: 1;
        font-weight: bold;
        padding: 12px;
        background: rgba(0, 0, 0, 0.8);
        color: #fff;
        border-radius: 2px;
    }

    /* Creates a small triangle extender for the tooltip */
    .d3-tip:after {
        box-sizing: border-box;
        display: inline;
        font-size: 10px;
        width: 100%;
        line-height: 1;
        color: rgba(0, 0, 0, 0.8);
        content: "\25BC";
        position: absolute;
        text-align: center;
    }

    /* Style northward tooltips differently */
    .d3-tip.n:after {
        margin: -1px 0 0 0;
        top: 100%;
        left: 0;
    }
</style>
<body>
<div class="container1" style="overflow: auto; max-width: 97%; width: 100%; padding-left: 30px; padding-right: 30px; margin-left: auto; margin-right: auto;">
    <form action="ranking.php" method="get">
    Jahr: <select name="jahr" id="Jh">
            <option value="2004">2004</option>
            <option value="2005">2005</option>
            <option value="2006">2006</option>
            <option value="2007">2007</option>
            <option value="2008">2008</option>
            <option value="2009">2009</option>
            <option value="2010">2010</option>
            <option value="2011">2011</option>
            <option value="2012">2012</option>
            <option value="2013">2013</option>
            <option value="2014">2014</option>
            <option value="2015">2015</option>
            <option value="2016">2016</option>
            <option value="2017">2017</option>
        </select>&nbsp;&nbsp;
        Typ: <select name="typ" id="Tp">
            <option value="StGemeinde">Gemeinde</option>
            <option value="StKath">Katholisch</option>
            <option value="StEvang">Evangelisch</option>
            <option value="StJp">Juristische Person</option>
        </select>
    </form>
    <script>
        var jahr=(findGetParameter("jahr")!=null)?findGetParameter("jahr"):2004;
        var typ=(findGetParameter("typ")!=null)?findGetParameter("typ"):"StGemeinde";
        document.cookie="jahr="+jahr;
        document.cookie="typ="+typ;
        $(function(){
            $("option").filter(function(){return this.value==jahr}).attr("selected","selected");
            $("option").filter(function(){return this.value==typ}).attr("selected","selected");

        });
        $("select").on("change",function(e){$("form").submit()})
    </script>
<figure class="Rankingdia"></figure>
<script src="http://d3js.org/d3.v3.min.js"></script>
<script src="http://labratrevenge.com/d3-tip/javascripts/d3.tip.v0.6.3.js"></script>
<script>

    var margin = {top: 40, right: 20, bottom: 60, left: 40},
        width = 2000 - margin.left - margin.right,
        height = 700 - margin.top - margin.bottom;

    var formatNumber = d3.format(".0d");

    var x = d3.scale.ordinal()
        .rangeRoundBands([0, width], .1, .4);

    var y = d3.scale.linear()
        .range([height, 0]);

    var xAxis = d3.svg.axis()
        .scale(x)
        .orient("bottom");

    var yAxis = d3.svg.axis()
        .scale(y)
        .orient("left")
        .tickFormat(formatNumber);

    var tip = d3.tip()
        .attr('class', 'd3-tip')
        .offset([-10, 0])
        .html(function(d) {
            return "<strong>Steuerfuss:</strong> <span style='color: #50e13f'>" + d.steuer + "</span><br />" +
                "<strong>Gemeinde:</strong> <span style='color:#50e13f'>" + d.gemeinde + "</span><br />"+
                "<strong>Jahr:</strong> <span style='color:#50e13f'>" + d.jahr + "</span><br />";
        })

    var svg = d3.select("figure").append("svg")
        .attr("width", width + margin.left + margin.right)
        .attr("height", height + margin.top + margin.bottom +140)
        .attr("style","padding-left: 30px;")
        .append("g")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    svg.call(tip);

    d3.tsv("RankingData.php", type, function(error, data) {
        data = data.sort(function(a, b) {
            return b.steuer - a.steuer
        });
        x.domain(data.map(function(d) { return d.gemeinde; }));
        y.domain([0, d3.max(data, function(d) { return d.steuer; })]);

        svg.append("g")
            .attr("class", "x axis")
            .attr("transform", "translate(0," + 600 + ")") //Hier ändern!
            .call(xAxis)
            .selectAll("text")
            .attr("y", 10)
            .attr("x", 10)
            .attr("dy", "-.20em")
            .attr("transform", "rotate(90)")
            .style("text-anchor", "start");

        svg.append("g")
            .attr("class", "y axis")
            .call(yAxis)
            .append("text")
            .attr("transform", "rotate(-90)")
            .attr("y", -50)
            .attr("dy", ".71em")

        svg.selectAll(".bar")
            .data(data)
            .enter().append("rect")
            .attr("class", "bar")
            .attr("x", function(d) { return x(d.gemeinde); })
            .attr("width", x.rangeBand())
            .attr("y", function(d) { return y(d.steuer); })
            .attr("height", function(d) { return height - y(d.steuer); })
            .on('mouseover', tip.show)
            .on('mouseout', tip.hide);
    });

    function type(d) {
        d.steuer = +d.steuer;
        return d;
    }

</script>
<!-- Bootstrap core JavaScript-->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</div>
</body>

</html>