/**
 * @author Sahithyen Kanaganayagam <mail@sahithyen.com>
 * @license MIT
 */

const m = require('mithril')

const Map = require('../models/map.js')

module.exports = {
  view: () => {
    return m('div.p-4.bg-white', [
      m('h4', Map.getSelectedLayer().name),
      m('p.my-1', [
        m('strong', Map.getSelectedLayer().description)
      ]),
      m('img', {
        src: Map.getLegendURL(),
        alt: 'legend'
      })
    ])
  }
}
