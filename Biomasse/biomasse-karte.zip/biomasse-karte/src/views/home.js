/**
 * @author Sahithyen Kanaganayagam <mail@sahithyen.com>
 * @license MIT
 */

const m = require('mithril')

const MapView = require('./map')

module.exports = {
  view: function () {
    return m('div', [
      // Karte
      m(MapView),

      // Intro
      m('div.container.mt-4#informationen', [
        m('h1', 'Biomasse'),
        m('hr'),
        m('p.lead', `
Biomasse ist ein Begriff, für den es viele, unterschiedliche Definitionen gibt.
Einfach gesagt bezeichnet Biomasse die Gesamtheit aller Lebewesen (tierisch und
auch pflanzlich), einschließlich des abgestorbenen Materials. Schaut man sich
die Biomasse im Kontext der erneuerbaren Energie an, werden alle organischen
Stoffe pflanzlichen oder tierischen Ursprungs, die als Energieträger genutzt
werden können, als Biomasse bezeichnet.
        `),

        m('p.lead', `
Auf der Karte wird genau diese Art der Biomasse dargestellt. Sie zeigt, in
welchen Teilen des Thurgaus, wie viel Potenzial in Biomasse existiert.
        `)
      ])
    ])
  }
}
