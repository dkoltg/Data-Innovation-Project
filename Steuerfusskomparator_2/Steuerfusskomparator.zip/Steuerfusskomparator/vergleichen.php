<?php
error_reporting(E_ALL ^ E_NOTICE);
$gemexist=true;
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Steuerfusskomparator-Vergleichen</title>

    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom fonts for this template-->
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="vendor/bootstrap/css/bootstrap.css" rel="stylesheet";>
    <!-- Navbar  -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
    <script src="//code.jquery.com/jquery-1.10.2.js"></script>
    <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
    <!-- Verlauf -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.5.0/Chart.min.js"></script>

</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top id="mainNav"">
<a class="navbar-brand" href="index.php">
        <span class='span-logo'>
          <img src='ressources/thurgau_logo.png' width="300" height="100" />
        </span>
</a>
<button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
</button>
<div class="collapse navbar-collapse" id="navbarResponsive">
    <ul class="nav navbar-nav navbar-right" id="navbarItems">
        <li class="nav-item" data-toggle="tooltip">
            <a class="nav-link" href="index.php">
                <span class="nav-link-text">Home</span>
            </a>
        </li>

        <li class="nav-item" data-toggle="tooltip">
            <a class="nav-link" href="vergleichen.php">
                <span class="nav-link-text">Vergleichen</span>
            </a>
        </li>

        <li class="nav-item" data-toggle="tooltip">
            <a class="nav-link" href="ranking.php">
                <span class="nav-link-text">Ranking</span>
            </a>
        </li>
    </ul>
</div>
</nav>

<!-- Gemeinde 1 , Gemeinde 2, submitgemeinde form -->
<div class="vergleichenForm"> <!-- Class found in css/sb-admin.css -->
<form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST" id="vergleichform">
    <table style="margin: 200px auto 0px;">
        <tbody>
        <tr>
            <td> <input type="text" class="form-control" style="max-width: 200px;"
                        name="Gem1" placeholder="Gemeinde 1" id="G1" value="<?php if (isset($_POST['Gem1'])) echo str_replace('\' ', '\'', ucwords(str_replace('\'', '\' ', strtolower($_POST['Gem1'])))); ?>"required></td>
            <td><input  type="text" class="form-control "
                       style="max-width: 200px;" name="Gem2"
                       placeholder="Gemeinde 2" id="G2" value="<?php if (isset($_POST['Gem2'])) echo str_replace('\' ', '\'', ucwords(str_replace('\'', '\' ', strtolower($_POST['Gem2'])))); ?>"required></td>
            <td> <select class="form-control" id="yearSel" name="year">
                    <option <?php if($_POST['year'] == '2017') {echo "selected=selected"; } ?>>2017</option>
                    <option <?php if($_POST['year'] == '2016') {echo "selected=selected"; } ?>>2016</option>
                    <option <?php if($_POST['year'] == '2015') {echo "selected=selected"; } ?>>2015</option>
                    <option <?php if($_POST['year'] == '2014') {echo "selected=selected"; } ?>>2014</option>
                    <option <?php if($_POST['year'] == '2013') {echo "selected=selected"; } ?>>2013</option>
                    <option <?php if($_POST['year'] == '2012') {echo "selected=selected"; } ?>>2012</option>
                    <option <?php if($_POST['year'] == '2011') {echo "selected=selected"; } ?>>2011</option>
                    <option <?php if($_POST['year'] == '2010') {echo "selected=selected"; } ?>>2010</option>
                    <option <?php if($_POST['year'] == '2009') {echo "selected=selected"; } ?>>2009</option>
                    <option <?php if($_POST['year'] == '2008') {echo "selected=selected"; } ?>>2008</option>
                    <option <?php if($_POST['year'] == '2007') {echo "selected=selected"; } ?>>2007</option>
                    <option <?php if($_POST['year'] == '2006') {echo "selected=selected"; } ?>>2006</option>
                    <option <?php if($_POST['year'] == '2005') {echo "selected=selected"; } ?>>2005</option>
                    <option <?php if($_POST['year'] == '2004') {echo "selected=selected"; } ?>>2004</option>
                </select></td>
            <td><input type="submit" class="btn btn-success" name="bvergleich"  value="Vergleichen"/></td>
        </tr>
        </tbody>
    </table>
</form>

</div>

<!-- js function for autofill -->
<script>
    $(function() {
        $( "#G1" ).autocomplete({
            source: 'vautofill.php'
        });
        $( "#G2" ).autocomplete({
            source: 'vautofill.php'
        });
    });
</script>
<!-- Diagram content -->
<?php

if(isset($_POST['bvergleich'])) {

    $gem1 = $_POST['Gem1'];
    $gem2 = $_POST['Gem2'];
    $jahr = $_POST['year'];

    $gem1Bevoelkerung = 0;
    $gem1Id = 0;
    $gem1StGemeinde = 0;
    $gem1StKath = 0;
    $gem1StEvang = 0;
    $gem1StJp = 0;

    $gem2Bevoelkerung = 0;
    $gem2Id = 0;
    $gem2StGemeinde = 0;
    $gem2StKath = 0;
    $gem2StEvang = 0;
    $gem2StJp = 0;

    $db = new SQLite3("ressources/Steuerfuss.sqlite");
    $gem1Query = "SELECT * FROM Gemeinden WHERE GeName LIKE'" . $gem1 . "'";
    $gem2Query = "SELECT * FROM Gemeinden WHERE GeName LIKE'" . $gem2 . "'";

    $gem1Result = $db->query($gem1Query);
    $gem2Result = $db->query($gem2Query);



    if ($row = $gem1Result->fetchArray()) {
            $gem1Bevoelkerung = $row["GeBevoelkerung"];
            $gem1Id = $row["GeId"];
        $gemName1= $row["GeName"];
    }else{
        $gemexist=false;

    }

    if ($row = $gem2Result->fetchArray()) {
        $gemName2= $row["GeName"];
        $gem2Bevoelkerung = $row["GeBevoelkerung"];
        $gem2Id = $row["GeId"];
    }else{
        $gemexist=false;

    }

    if(!$gemexist){
        echo'<br><div class="alert alert-danger vergleichenTable" style="max-width: 300px;">
   Bitte geben Sie eine Gemeinde an, welche sich im Thurgau befindet.
</div>';
        exit();
    }

    $gem1StQuery = "SELECT * FROM Steuerfuesse WHERE GeId='" . $gem1Id . "' AND StJahr='" . $jahr . "'";
    $gem2StQuery = "SELECT * FROM Steuerfuesse WHERE GeId='" . $gem2Id . "' AND StJahr='" . $jahr . "'";

    $gem1StResult = $db->query($gem1StQuery);
    $gem2StResult = $db->query($gem2StQuery);

    while ($row = $gem1StResult->fetchArray()) {
        $gem1StGemeinde = $row["StGemeinde"];
        $gem1StKath = $row["StKath"];
        $gem1StEvang = $row["StEvang"];
        $gem1StJp = $row["StJp"];
    }

    while ($row = $gem2StResult->fetchArray()) {
        $gem2StGemeinde = $row["StGemeinde"];
        $gem2StKath = $row["StKath"];
        $gem2StEvang = $row["StEvang"];
        $gem2StJp = $row["StJp"];
    }

    $db->close();

    echo '
    <div class="vergleichenTable">
    <table class="table table-bordered" id="vergleichstabelle" >
        <thead class="thead-dark">
            <tr>
                <th scope="col"></th>
                <th scope="col">'.$gemName1.'</th>
                <th scope="col">'.$gemName2.'</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <th scope="row">Einwohner</th>
                <td class="ge1val">'.$gem1Bevoelkerung.'</td>
                <td class="ge2val">'.$gem2Bevoelkerung.'</td>
            </tr>
            <tr>
                <th scope="row">Steuerfuss Gemeinde</th>
                <td class="ge1val">'.$gem1StGemeinde.'%</td>
                <td class="ge2val">'.$gem2StGemeinde.'%</td>
            </tr>
            <tr>
                <th scope="row">Steuerfuss Katholisch</th>
                <td class="ge1val">'.$gem1StKath.'%</td>
                <td class="ge2val">'.$gem2StKath.'%</td>
            </tr>
            <tr>
                <th scope="row">Steuerfuss Evangelisch</th>
                <td class="ge1val">'.$gem1StEvang.'%</td>
                <td class="ge2val">'.$gem2StEvang.'%</td>
            </tr>
            <tr>
                <th scope="row">Steuerfuss Juristische Person</th>
                <td class="ge1val">'.$gem1StJp.'%</td>
                <td class="ge2val">'.$gem2StJp.'%</td>
            </tr>
        </tbody>
    </table>
    </div><br>';
    echo ' <script>
            setTimeout(function() {
                if($( "#vergleichstabelle" ).length){
                    var gemeinde1values = $(".ge1val");
                    var gemeinde2values = $(".ge2val");
                    var gemeinde1ValArray = [];
                    var gemeinde2ValArray = [];
                    
                    
                    gemeinde1values.each(function(){
                        gemeinde1ValArray.push($(this));
                    });
                    
                    gemeinde2values.each(function(){
                        gemeinde2ValArray.push($(this));
                    });
                    
                    $.each(gemeinde1ValArray, function(index, g1Element) {
                        $.each(gemeinde2ValArray, function(indx, g2Element) {
                            var g1Num = g1Element.text();
                            var g2Num = g2Element.text();
                            console.log(g1Num);
                            console.log(g2Num);
                            if(index !== 0 && index === indx){
                                if(g1Num > g2Num){
                                    g1Element.addClass("bad");
                                    g2Element.addClass("good");
                                } 
                                if(g1Num < g2Num){
                                    g2Element.addClass("bad");
                                    g1Element.addClass("good");
                                }
                            } 
                        });
                    });
                }
           }, 10);
    </script>';


    //Verlauf

    $db = new SQLite3("ressources/Steuerfuss.sqlite");

    $v1Query= "SELECT StGemeinde, StKath, StEvang, STJp FROM Steuerfuesse WHERE GeId='".$gem1Id."' ORDER BY StJahr ASC";
    $v2Query= "SELECT StGemeinde, StKath, StEvang, STJp FROM Steuerfuesse WHERE GeId='".$gem2Id."' ORDER BY StJahr ASC";

    $v1QueryRes = $db->query($v1Query);
    $v2QueryRes = $db->query($v2Query);

    $v1Gemeinde= Array();
    $v1Kath= Array();
    $v1Evang= Array();
    $v1Jp= Array();

    while ($v1Data = $v1QueryRes->fetchArray()) {
        $v1Gemeinde[] = $v1Data["StGemeinde"];
        $v1Kath[] = $v1Data["StKath"];
        $v1Evang[] = $v1Data["StEvang"];
        $v1Jp[] = $v1Data["StJp"];
    }
    $sonGemeinde1= $v1Gemeinde;
    $sonKath1=$v1Kath;
    $sonEvang1=$v1Evang;
    $sonJp1=$v1Jp;



    $v2Gemeinde= Array();
    $v2Kath= Array();
    $v2Evang= Array();
    $v2Jp= Array();

    while ($v2Data = $v2QueryRes->fetchArray()) {
        $v2Gemeinde[] = $v2Data["StGemeinde"];
        $v2Kath[]= $v2Data["StKath"];
        $v2Evang[]= $v2Data["StEvang"];
        $v2Jp[] = $v2Data["StJp"];
    }
    $db->close();

    $sonGemeinde2=$v2Gemeinde;
    $sonKath2=$v2Kath;
    $sonEvang2=$v2Evang;
    $sonJp2=$v2Jp;




    ?>
<div class="container">

    <div class="Vergleich-Verlauf">
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-6">
                    <canvas class="vergleichscanvas" id="line-chart" width="500" height="400"></canvas>
                </div>
                <div class="col-sm-12 col-md-12 col-lg-6">
                    <canvas class="vergleichscanvas" id="line-chart1" width="500" height="400"></canvas>
                </div>
            </div>
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-6">
                    <canvas class="vergleichscanvas" id="line-chart2" width="500" height="400"></canvas>
                </div>
                <div class="col-sm-12 col-md-12 col-lg-6">
                    <canvas class="vergleichscanvas" id="line-chart3" width="500" height="400"></canvas>
                </div>
            </div>
    </div>
</div>
    <br>
    <br>
    <script>
        var Gemeinde1 = <?php echo  json_encode($sonGemeinde1) ?>;
        var Gemeinde2 = <?php echo  json_encode($sonGemeinde2) ?>;
        var Kath1 = <?php echo  json_encode($sonKath1) ?>;
        var Kath2 = <?php echo  json_encode($sonKath2) ?>;
        var Evang1 = <?php echo  json_encode($sonEvang1) ?>;
        var Evang2 = <?php echo json_encode($sonEvang2)?>;
        var Jp1 = <?php echo  json_encode($sonJp1) ?>;
        var Jp2 = <?php echo json_encode($sonJp2) ?>;
        var Gemeindename1 = <?php echo json_encode($gemName1) ?>;
        var Gemeindename2 = <?php echo json_encode($gemName2) ?>;


        new Chart(document.getElementById("line-chart1"), {
            type: 'line',
            data: {
                labels: [2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017],
                datasets: [{
                    data: Kath1,
                    label: Gemeindename1,
                    borderColor: "#000fcd",
                    fill: false
                }, {
                    data: Kath2,
                    label: Gemeindename2,
                    borderColor: "#e84654",
                    fill: false
                }
                ]
            },
            options: {
                tooltips: {
                    enabled: true,
                    mode: 'index',
                    position: 'nearest',

                },
                title: {
                    display: true,
                    text: 'Steuerfuss (Katholisch) von '+Gemeindename1+' und '+Gemeindename2+' im Vergleich.'
                },
                scales:{
                    yAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: 'Steuerfuss in %'
                        },
                        ticks: {
                            max:400,
                            min:200,
                            stepSize:10,
                        }
                    }]
                }
            }
        });

        new Chart(document.getElementById("line-chart"), {
            type: 'line',
            data: {
                labels: [2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017],
                datasets: [{
                    data: Gemeinde1,
                    label: Gemeindename1,
                    borderColor: "#000fcd",
                    fill: false
                }, {
                    data: Gemeinde2,
                    label: Gemeindename2,
                    borderColor: "#e84654",
                    fill: false
                }
                ]
            },
            options: {
                tooltips: {
                    enabled: true,
                    mode: 'index',
                    position: 'nearest',

                },
                title: {
                    display: true,
                    text: 'Steuerfuss (Gemeinde) von '+Gemeindename1+' und '+Gemeindename2+' im Vergleich.'
                },
                scales:{
                    yAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: 'Steuerfuss in %'
                        },
                        ticks: {
                            max:200,
                            min:20,
                            stepSize:10,
                        }
                    }]
                }

            }
        });

        new Chart(document.getElementById("line-chart2"), {
            type: 'line',
            data: {
                labels: [2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017],
                datasets: [{
                    data: Evang1,
                    label: Gemeindename1,
                    borderColor: "#000fcd",
                    fill: false
                }, {
                    data: Evang2,
                    label: Gemeindename2,
                    borderColor: "#e84654",
                    fill: false
                }
                ]
            },
            options: {
                tooltips: {
                    enabled: true,
                    mode: 'index',
                    position: 'nearest',

                },
                title: {
                    display: true,
                    text: 'Steuerfuss (Evangelisch) von '+Gemeindename1+' und '+Gemeindename2+' im Vergleich.'
                },
                scales:{
                    yAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: 'Steuerfuss in %'
                        },
                        ticks: {
                            max:400,
                            min:200,
                            stepSize:10,
                        }
                    }]
                }

            }
        });

        new Chart(document.getElementById("line-chart3"), {
            type: 'line',
            data: {
                labels: [2004, 2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016, 2017],
                datasets: [{
                    data: Jp1,
                    label: Gemeindename1,
                    borderColor: "#000fcd",
                    fill: false
                }, {
                    data: Jp2,
                    label: Gemeindename2,
                    borderColor: "#e84654",
                    fill: false
                }
                ]
            },
            options: {
                tooltips: {
                    enabled: true,
                    mode: 'index',
                    position: 'nearest',

                },

                title: {
                    display: true,
                    text: 'Steuerfuss (juristische Person) von '+Gemeindename1+' und '+Gemeindename2+' im Vergleich.'
                },

                scales:{
                    yAxes: [{
                        scaleLabel: {
                            display: true,
                            labelString: 'Steuerfuss in %'
                        },
                        ticks: {
                            max:400,
                            min:200,
                            stepSize:10,
                        }
                    }]
                }

            }
        });
    </script>
    <?php
}
?>



</body>
</html>