<?php
/**
 * Created by PhpStorm.
 * User: Philipp Schuepbach
 * Date: 07.11.2017
 * Time: 10:21
 */
require 'datenbank.php';
error_reporting(E_ALL ^ E_NOTICE);
$DB;
try {
    $DB = new datenbank("ressources/Steuerfuss.sqlite");
} catch (PDOException $e) {
    header("HTTP/1.1 500 Internal Server Error");
    die(0);
}
try {

    if(isset($_GET['Filter'])) {
        $filter = $_GET['Filter'];
        $query = $DB->getQueryAsArray("SELECT GeName, GeBevoelkerung, StJahr, StGemeinde, StKath, StEvang, StJp FROM Gemeinden NATURAL JOIN Steuerfuesse;");
        $res = array();
        foreach ($query as $p) {
            $post = array();
            foreach ($p as $e) {
                array_push($post, $e);
            }
            array_push($res, $post);
        }
        echo '{"data":' . json_encode($res) . '}';
        die(0);
    }else{
        $query = $DB->getQueryAsArray("SELECT GeName, GeBevoelkerung, StJahr, StGemeinde, StKath, StEvang, StJp FROM Gemeinden NATURAL JOIN Steuerfuesse;");
        $res = array();
        foreach ($query as $p) {
            $post = array();
            foreach ($p as $e) {
                array_push($post, $e);
            }
            array_push($res, $post);
        }
        echo '{"data":' . json_encode($res) . '}';
        die(0);
    }
} catch (Exception $e) {
    header("HTTP/1.1 500 Internal Server Error");
    die(0);
}
