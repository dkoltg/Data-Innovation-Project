# erneuerbare-energien-game

